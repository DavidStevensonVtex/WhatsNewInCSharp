﻿// Pattern Matching
// https://docs.microsoft.com/en-us/dotnet/csharp/pattern-matching

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


class PatternMatchingDetailed
{
	static void Main(string[] args)
	{
	}
}

