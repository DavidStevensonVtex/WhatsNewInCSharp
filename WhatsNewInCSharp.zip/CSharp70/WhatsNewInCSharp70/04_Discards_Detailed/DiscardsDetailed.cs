﻿// Discards - C# Guide
// https://docs.microsoft.com/en-us/dotnet/csharp/discards

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;



class DiscardsDetailed
{

	static void Main(string[] args)
	{
	}
}
