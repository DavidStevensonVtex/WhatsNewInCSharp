﻿// Main() and command-line arguments (C# Programming Guide)
// https://docs.microsoft.com/en-us/dotnet/csharp/programming-guide/main-and-command-args/index

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


class AsyncMainDetailed
{
	static void Main(string[] args)
	{
	}
}
